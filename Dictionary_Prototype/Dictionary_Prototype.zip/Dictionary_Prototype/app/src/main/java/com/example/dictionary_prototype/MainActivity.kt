package com.example.dictionary_prototype

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.dictionary_prototype.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import retrofit2.Response
import java.io.InputStream
import java.nio.charset.StandardCharsets
import java.util.HashMap
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import androidx.core.view.GravityCompat
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar

class MainActivity : AppCompatActivity() {
    private val REQUEST_CODE_FAVORITES = 1
    private lateinit var binding: ActivityMainBinding
    private lateinit var toggle: ActionBarDrawerToggle
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var adapter: MeaningAdapter
    private val favoriteWords: MutableSet<String> = mutableSetOf()
    private lateinit var dictionary: HashMap<String, String>
    private lateinit var favoritesActivityLauncher: ActivityResultLauncher<Intent>
    private lateinit var dbHelper: SearchHistoryDatabaseHelper // Declare dbHelper for SQLite


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = SearchHistoryDatabaseHelper(this) // Initialize dbHelper

        favoritesActivityLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val updatedFavorites = result.data?.getStringArrayListExtra("updatedFavorites")
                val selectedWord = result.data?.getStringExtra("selectedWord")

                if (updatedFavorites != null) {
                    favoriteWords.clear()
                    favoriteWords.addAll(updatedFavorites)

                    // Save updated favorites to SharedPreferences
                    saveFavoritesToSharedPreferences()
                }
                if (selectedWord != null) {
                    // Search for the selected word when a word is tapped in the favorites list
                    searchWord(selectedWord)
                }
            }
        }

        binding.meaningRecyclerView.layoutManager = LinearLayoutManager(this)
        adapter = MeaningAdapter(mutableListOf())
        binding.meaningRecyclerView.adapter = adapter
        binding.searchInput.showSoftInputOnFocus = true
        binding.searchInput.isLongClickable = false // Prevent long clicks (clipboard popup)
        binding.searchInput.setTextIsSelectable(false) // Disable text selection (clipboard)


        // Initialize Toolbar
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        // Initialize DrawerLayout and toggle
        drawerLayout = findViewById(R.id.drawer_layout)
        toggle = ActionBarDrawerToggle(
            this,
            drawerLayout,
            toolbar,
            R.string.open_drawer,
            R.string.close_drawer
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        // Set up menu icon click listener to open the navigation drawer
        val menuIcon: ImageView = findViewById(R.id.menu_icon)
        menuIcon.setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START) // Opens the drawer from the left side
        }

        // Set up navigation drawer menu actions
        binding.navView.setNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.nav_home -> {}

                R.id.nav_favorites -> {
                    // Launch FavoritesActivity when "Favorites" is selected
                    val intent = Intent(this, FavoritesActivity::class.java)
                    intent.putStringArrayListExtra("favoriteWords", ArrayList(favoriteWords)) // Pass favorite words
                    favoritesActivityLauncher.launch(intent)  // Use the new launcher here
                }
                R.id.nav_history -> {
                    // Launch HistoryActivity
                    val intent = Intent(this, HistoryActivity::class.java)
                    startActivity(intent)
                }

                else -> {
                    // If a favorite word was clicked, search for that word
                    val word = it.title.toString()
                    searchWord(word)
                }
            }
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }

        // Load dictionary data from the assets
        loadDictionary()

        // Add TextWatcher to listen for input changes (No suggestions)
        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {}
        })

        // Set up search button click listener
        binding.searchBtn.setOnClickListener {
            val word = binding.searchInput.text.toString().trim().toLowerCase()
            searchWord(word)
        }

        // Load favorites from SharedPreferences
        loadFavoritesFromSharedPreferences()

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_FAVORITES && resultCode == RESULT_OK && data != null) {
            // Retrieve the updated list of favorite words from FavoritesActivity
            val updatedFavorites = data.getStringArrayListExtra("updatedFavorites")
            if (updatedFavorites != null) {
                favoriteWords.clear()
                favoriteWords.addAll(updatedFavorites)

                // Save updated favorites to SharedPreferences
                saveFavoritesToSharedPreferences()

                // Update the favorites menu in the drawer
            }
        }
    }

    // Load dictionary data from JSON file in assets
    private fun loadDictionary() {
        dictionary = HashMap()
        try {
            val inputStream: InputStream = assets.open("en-dz.json")
            val size: Int = inputStream.available()
            val buffer = ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()
            val jsonString = String(buffer, StandardCharsets.UTF_8)
            val jsonObject = JSONObject(jsonString)
            val keys = jsonObject.keys()

            // Log the number of keys loaded
            var wordCount = 0
            while (keys.hasNext()) {
                val key = keys.next()
                val value = jsonObject.getString(key)
                dictionary[key.toLowerCase()] = value
                wordCount++
            }

            // Log total words loaded
            println("Total words loaded into the dictionary: $wordCount")

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Search both local dictionary and the API
    private fun searchWord(word: String) {
        addToSearchHistory(word) // Add to search history database
        val localDefinition = dictionary[word]
        if (localDefinition != null) {
            // Split the definition into words
            val words = localDefinition.split(" ")

            // Combine the first word with full opacity and the second word with reduced opacity
            val formattedDefinition = if (words.size > 2) {
                "<span style='opacity:1;'>${words[0]}</span>&nbsp; " +  // First word with full opacity
                        "<span style='opacity:0.4;'>${words[1]}</span> " +  // Second word with reduced opacity
                        "<br>" + words.subList(2, words.size)
                    .joinToString(" ")  // Remaining words on the next line
            } else if (words.size == 2) {
                "<span style='opacity:1;'>${words[0]}</span> " +  // First word with full opacity
                        "<span style='opacity:0.4;'>${words[1]}</span>&nbsp"  // Second word with reduced opacity
            } else {
                "<span style='opacity:1;'>${words[0]}</span>"  // If only one word, just show it with full opacity
            }

            // Wrap the definition in bold HTML tags
            val boldDefinition = "<html><body><b>$formattedDefinition</b></body></html>"

            // Display the local definition in the WebView
            binding.definitionWebview.visibility = View.VISIBLE
            binding.definitionWebview.loadData(boldDefinition, "text/html", "UTF-8")
            binding.wordTextview.text = word

            // Show the favorite icon when a word and its definition appear
            binding.favoriteIcon.visibility = View.VISIBLE

            // Check if the word is in favorites
            updateFavoriteIcon(word)
            binding.favoriteIcon.setOnClickListener {
                if (favoriteWords.contains(word)) {
                    // Remove the word from favorites
                    favoriteWords.remove(word)
                    binding.favoriteIcon.setImageResource(R.drawable.ic_favorite_border)
                    Toast.makeText(this, "$word removed from favorites", Toast.LENGTH_SHORT).show()
                } else {
                    // Add the word to favorites
                    favoriteWords.add(word)
                    binding.favoriteIcon.setImageResource(R.drawable.ic_favorite_filled)
                    Toast.makeText(this, "$word added to favorites", Toast.LENGTH_SHORT).show()
                }

                // Save the updated favorites to SharedPreferences
                saveFavoritesToSharedPreferences()

            }
        } else {
            // If not found locally, hide the favorite icon
            binding.definitionWebview.visibility = View.GONE
            binding.definitionWebview.loadData("", "text/html", "UTF-8")
            binding.favoriteIcon.visibility = View.GONE
        }

        // Regardless of local search, proceed with the network call
        getMeaning(word)

    }

    private fun addToSearchHistory(word: String) {
        dbHelper.insertWord(word)  // Add the word to the database
    }

    // Update favorite icon based on favorite state
    private fun updateFavoriteIcon(word: String) {
        if (favoriteWords.contains(word)) {
            binding.favoriteIcon.setImageResource(R.drawable.ic_favorite_filled) // Filled favorite icon
        } else {
            binding.favoriteIcon.setImageResource(R.drawable.ic_favorite_border) // Unfilled favorite icon
        }
    }

    // Fallback to API call
    private fun getMeaning(word: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response: Response<List<WordResult>> = RetrofitInstance.dictionaryApi.getMeaning(word)

                // Log the raw response for more clarity
                println("Raw API Response: ${response.raw()}")

                withContext(Dispatchers.Main) {
                    if (response.isSuccessful) {
                        val responseBody = response.body()
                        println("API Response Body: $responseBody")

                        responseBody?.firstOrNull()?.let { wordResult ->
                            setUI(wordResult)
                        } ?: run {
                            println("No data for word: $word")
                            binding.wordTextview.text = "No definition found"
                        }
                    } else {
                        println("Error Code: ${response.code()} | Message: ${response.message()}")
                        binding.wordTextview.text = "Error: ${response.code()} - ${response.message()}"
                    }
                }
            } catch (e: Exception) {
                println("Exception occurred: ${e.localizedMessage}")
                withContext(Dispatchers.Main) {
                    binding.wordTextview.text = "An error occurred: ${e.localizedMessage}"
                }
            }
        }
    }


    private fun setUI(response: WordResult) {
        // Update the word and phonetic
        binding.wordTextview.text = response.word

        if (!response.phonetic.isNullOrBlank()) {
            binding.phoneticTextview.text = response.phonetic
            binding.phoneticTextview.visibility = View.VISIBLE
        } else {
            binding.phoneticTextview.text = "Phonetic not available"
            binding.phoneticTextview.visibility = View.VISIBLE  // Make it visible with placeholder
        }

        // Update RecyclerView with meanings
        adapter.updateNewData(response.meanings)
        binding.meaningRecyclerView.visibility =
            View.VISIBLE  // Show the RecyclerView with the results

        // Show the favorite icon when definitions appear
        binding.favoriteIcon.visibility = View.VISIBLE

        // Check if the word is in favorites
        updateFavoriteIcon(response.word)
    }

    // Load favorites from SharedPreferences
    private fun loadFavoritesFromSharedPreferences() {
        val savedFavorites = getSharedPreferences("FavoriteWords", MODE_PRIVATE)
            .getStringSet("favoriteWords", emptySet())
        favoriteWords.clear()
        favoriteWords.addAll(savedFavorites ?: emptySet())
    }

    // Save favorites to SharedPreferences
    private fun saveFavoritesToSharedPreferences() {
        val sharedPreferences = getSharedPreferences("FavoriteWords", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putStringSet("favoriteWords", favoriteWords)
        editor.apply()
    }
}
